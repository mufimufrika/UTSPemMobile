import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  ScrollView,
  Alert,
} from 'react-native';

const menus = [
  { title: 'Menu 1', icon: '📚', color: '#7C3AED' },
  { title: 'Menu 2', icon: '📝', color: '#2563EB' },
  { title: 'Menu 3', icon: '🎯', color: '#EC4899' },
  { title: 'Menu 4', icon: '⚙️', color: '#0D9488' },
];

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeMenu, setActiveMenu] = useState('');

  const login = () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Perhatian', 'Email dan password harus diisi!');
      return;
    }

    setIsLoggedIn(true);
  };

  const logout = () => {
    setIsLoggedIn(false);
    setActiveMenu('');
    setPassword('');
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#4338CA" />

      {!isLoggedIn ? (
        <View style={styles.loginPage}>
          <View style={styles.loginCard}>
            <View style={styles.logo}>
              <Text style={styles.logoText}>M</Text>
            </View>

            <Text style={styles.appName}>MY APP</Text>
            <Text style={styles.subtitle}>Mufrika Muayyidah Ramadhani</Text>
            <Text style={styles.description}>
              Selamat datang! Silakan login untuk melanjutkan.
            </Text>

            <Text style={styles.label}>EMAIL</Text>
            <TextInput
              style={styles.input}
              placeholder="Masukkan email"
              placeholderTextColor="#94A3B8"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />

            <Text style={styles.label}>PASSWORD</Text>
            <TextInput
              style={styles.input}
              placeholder="Masukkan password"
              placeholderTextColor="#94A3B8"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
            />

            <TouchableOpacity style={styles.loginButton} onPress={login}>
              <Text style={styles.loginButtonText}>LOGIN →</Text>
            </TouchableOpacity>

            <Text style={styles.footer}>
              APLIKASI UTS PEMROGRAMAN MOBILE 1
            </Text>
          </View>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.homePage}>
          <View style={styles.header}>
            <View>
              <Text style={styles.headerSmall}>MY APP</Text>
              <Text style={styles.homeTitle}>HOME PAGE</Text>
            </View>

            <View style={styles.avatar}>
              <Text style={styles.avatarText}>M</Text>
            </View>
          </View>

          <View style={styles.welcomeCard}>
            <Text style={styles.welcomeSmall}>WELCOME, USER 👋</Text>
            <Text style={styles.welcomeName}>
              Halo, Mufrika!
            </Text>
            <Text style={styles.welcomeDesc}>
              Semangat belajar dan semoga harimu menyenangkan.
            </Text>
          </View>

          <Text style={styles.sectionTitle}>Menu Utama</Text>
          <Text style={styles.sectionDesc}>
            Pilih menu yang ingin kamu buka
          </Text>

          <View style={styles.menuGrid}>
            {menus.map((menu) => (
              <TouchableOpacity
                key={menu.title}
                style={[
                  styles.menuCard,
                  { backgroundColor: menu.color },
                ]}
                onPress={() => setActiveMenu(menu.title)}
              >
                <Text style={styles.menuIcon}>{menu.icon}</Text>
                <Text style={styles.menuTitle}>{menu.title}</Text>
                <Text style={styles.menuArrow}>Buka menu →</Text>
              </TouchableOpacity>
            ))}
          </View>

          {activeMenu !== '' && (
            <View style={styles.selectedCard}>
              <Text style={styles.selectedTitle}>
                {activeMenu}
              </Text>
              <Text style={styles.selectedText}>
                Kamu memilih {activeMenu}. Menu ini berhasil dibuka!
              </Text>
              <TouchableOpacity
                onPress={() => setActiveMenu('')}
              >
                <Text style={styles.closeText}>Tutup menu</Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={styles.infoCard}>
            <Text style={styles.infoTitle}>✨ Tetap Produktif!</Text>
            <Text style={styles.infoText}>
              Kerjakan tugas sedikit demi sedikit dan jangan lupa
              istirahat.
            </Text>
          </View>

          <TouchableOpacity style={styles.logoutButton} onPress={logout}>
            <Text style={styles.logoutText}>↪  LOGOUT</Text>
          </TouchableOpacity>

          <Text style={styles.homeFooter}>Dibuat oleh Mufrika 💜</Text>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: '#EEF2FF',
  },
  loginPage: {
    flex: 1,
    justifyContent: 'center',
    padding: 22,
    backgroundColor: '#4338CA',
  },
  loginCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 26,
    padding: 25,
    alignItems: 'stretch',
    elevation: 8,
  },
  logo: {
    alignSelf: 'center',
    width: 65,
    height: 65,
    borderRadius: 22,
    backgroundColor: '#EDE9FE',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  logoText: {
    fontSize: 34,
    fontWeight: 'bold',
    color: '#6D28D9',
  },
  appName: {
    fontSize: 27,
    fontWeight: '900',
    color: '#312E81',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 13,
    color: '#64748B',
    textAlign: 'center',
    marginTop: 5,
  },
  description: {
    fontSize: 13,
    color: '#64748B',
    textAlign: 'center',
    marginTop: 18,
    marginBottom: 22,
    lineHeight: 20,
  },
  label: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#475569',
    marginBottom: 7,
    marginTop: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#DDD6FE',
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 13,
    fontSize: 14,
    color: '#1E293B',
  },
  loginButton: {
    backgroundColor: '#6D28D9',
    borderRadius: 12,
    padding: 15,
    alignItems: 'center',
    marginTop: 25,
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 15,
  },
  footer: {
    color: '#94A3B8',
    textAlign: 'center',
    fontSize: 9,
    marginTop: 23,
  },
  homePage: {
    flexGrow: 1,
    padding: 22,
    paddingTop: 30,
    paddingBottom: 35,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  headerSmall: {
    color: '#6D28D9',
    fontSize: 12,
    fontWeight: 'bold',
    letterSpacing: 2,
  },
  homeTitle: {
    color: '#1E1B4B',
    fontSize: 25,
    fontWeight: '900',
    marginTop: 4,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 18,
    backgroundColor: '#6D28D9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  welcomeCard: {
    backgroundColor: '#4F46E5',
    borderRadius: 22,
    padding: 22,
    marginBottom: 28,
  },
  welcomeSmall: {
    color: '#DDD6FE',
    fontSize: 11,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  welcomeName: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 12,
  },
  welcomeDesc: {
    color: '#E0E7FF',
    fontSize: 13,
    lineHeight: 20,
    marginTop: 8,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1E1B4B',
  },
  sectionDesc: {
    color: '#64748B',
    fontSize: 12,
    marginTop: 5,
    marginBottom: 16,
  },
  menuGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  menuCard: {
    width: '48%',
    minHeight: 135,
    borderRadius: 19,
    padding: 15,
    marginBottom: 13,
    justifyContent: 'center',
  },
  menuIcon: {
    fontSize: 27,
    marginBottom: 10,
  },
  menuTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  menuArrow: {
    color: '#FFFFFF',
    fontSize: 11,
    marginTop: 7,
  },
  selectedCard: {
    backgroundColor: '#FFFFFF',
    padding: 18,
    borderRadius: 16,
    marginTop: 5,
    marginBottom: 15,
  },
  selectedTitle: {
    color: '#4F46E5',
    fontSize: 18,
    fontWeight: 'bold',
  },
  selectedText: {
    color: '#475569',
    marginTop: 7,
    lineHeight: 20,
  },
  closeText: {
    color: '#6D28D9',
    fontWeight: 'bold',
    marginTop: 12,
  },
  infoCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 18,
    marginTop: 7,
  },
  infoTitle: {
    color: '#312E81',
    fontSize: 16,
    fontWeight: 'bold',
  },
  infoText: {
    color: '#64748B',
    fontSize: 13,
    lineHeight: 20,
    marginTop: 7,
  },
  logoutButton: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#C4B5FD',
    borderRadius: 13,
    padding: 14,
    alignItems: 'center',
    marginTop: 22,
  },
  logoutText: {
    color: '#6D28D9',
    fontWeight: 'bold',
    fontSize: 14,
  },
  homeFooter: {
    textAlign: 'center',
    color: '#94A3B8',
    fontSize: 11,
    marginTop: 20,
  },
});
